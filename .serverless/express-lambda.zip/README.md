# Aws-lambda-serverless


npx serverless deploy
when you command: - it shoudl ask you to login or register and then deploy. 





